# Plano do site Ca'as Consultoria

Base: sua landing atual. Posicionamento mantido: **Head of Operations as a Service (HOaaS)**, com o diagnóstico como porta de entrada.

## Regra do site
Cada página tem **uma** conversão principal. O resto é caminho até ela.

## Mapa de páginas

| Página | Arquivo | Conteúdo | Conversão principal | Fase |
|---|---|---|---|---|
| Home | `index.html` | Promessa, sintoma, modelo, frentes, diagnóstico, prova, CTA | Clique no WhatsApp (diagnóstico) | Entregue |
| Serviços | `servicos.html` | 5 serviços: diagnóstico, projeto, operação fracionada, mentoria de líderes, mentoria de vendas | WhatsApp já com o serviço escolhido na mensagem | Entregue |
| Sobre | `sobre.html` | Origem, missão, 3 valores, trajetória, fechamento de confiança | WhatsApp (diagnóstico) | Entregue |
| Artigo SEO | `head-de-operacoes-fracionada.html` | Responde "o que é e quando contratar" | Diagnóstico; secundário: guia gratuito | Entregue |
| Diagnóstico (página própria) | `diagnostico.html` | Etapas, entregável, crédito no projeto, perguntas frequentes | WhatsApp | Fase 2 |
| Blog / newsletter | `blog/` | Arquivo da "Desenrolando Operações", um artigo por dor | Assinar newsletter | Fase 2 |
| Casos e depoimentos | `casos.html` | 1 caso por cliente, com autorização | WhatsApp | Fase 2, só com prova real |
| Privacidade | `privacidade.html` | Política LGPD | Nenhuma (obrigatória) | Pendente: hoje o link do rodapé não leva a nada |

Menu: O modelo, Serviços, Sobre, Artigos + botão "Quero meu diagnóstico". Máximo 5 itens.

## Estrutura da home (ordem e função)

1. **Hero**: headline de 8 segundos, sub que quebra a objeção, 2 botões (principal: diagnóstico; secundário: guia). Função: o visitante entende em 8s o que você faz e para quem.
2. **Faixa de âncoras**: 20+ anos, 10+ anos liderando, faixa de faturamento atendida. Função: credibilidade sem depoimento.
3. **Sintoma**: lista de 7 dores. Função: reconhecimento ("é isso que acontece aqui").
4. **O modelo (HOaaS)**: 3 benefícios. Função: explicar o formato e tirar o medo do custo fixo.
5. **O que eu faço**: 5 frentes. Função: mostrar escopo, linkando para Serviços.
6. **Prova social**: espaço reservado, invisível até haver depoimento autorizado. Função: reduzir risco.
7. **Diagnóstico**: 3 etapas + crédito no projeto. Função: o primeiro passo pequeno e concreto.
8. **Para quem é / não é**: filtro. Função: qualificar o lead antes da conversa.
9. **CTA final** + guia gratuito. Função: capturar quem ainda não quer conversar.
10. **Rodapé**: contatos e privacidade.

A landing atual também tem mentorias, setor contábil e newsletter. Na home nova, mentorias e contabilidade ficam em Serviços e Sobre, para a home não vender tudo ao mesmo tempo.

## Contrapontos
- **Sem prova social, o site pede confiança no escuro.** As âncoras (20 anos, 10 anos, faixa de faturamento) seguram por ora. O primeiro depoimento autorizado entra na home antes de qualquer outra melhoria.
- **Duas ofertas no mesmo site (HOaaS e mentorias) competem.** Mantive HOaaS como principal e as mentorias como serviço de apoio, sem CTA na home.
- **Privacidade e LGPD**: a página de política não existe ainda. Preciso do seu texto ou de um modelo revisado por quem entende de LGPD.
- **SEO leva meses.** A página-artigo é a primeira de uma série. Uma só não move posição.
